YouTube Cobalt AdFree blue redesign browser screenshots
Source commit: 7d040d0749cad40ff0888902268ff77d51779921

Captured in Chromium at 1920 x 1080 from the current app UI code.
App overlay code and styles are used unchanged. A neutral backdrop and Arial
browser font replace the unavailable YouTube TV page. Comments and native
quality/report APIs use synthetic sample data, labeled on every screenshot.
These are browser previews, not LG TV/Cobalt runtime captures.

01-settings.png: Settings and video quality
02-captions-dearrow.png: Caption preferences and optional DeArrow
03-sponsorblock.png: SponsorBlock category controls
04-diagnostics.png: Diagnostics with labeled sample native report
05-comments.png: Fully expanded comments
06-replies.png: Fully expanded replies
